import psycopg2, json, time
from datetime import datetime
import random

DB_CONFIG = {
    "host": "localhost",
    "dbname": "breath",
    "user": "postgres",
    "password": "password",
    "port": 5432
}

def update_all_pets():
    conn = psycopg2.connect(**DB_CONFIG)
    cursor = conn.cursor()

    # Fetch all pet IDs and their history
    cursor.execute("SELECT pet_id, vitals_history FROM pet_vitals")
    pets = cursor.fetchall()

    for pet_id, history in pets:
        history = history if history else []

        # Simulate new RPM entry
        new_rpm = random.randint(8, 35)
        new_entry = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "rpm": new_rpm
        }

        # Append and trim to last 24h
        history.append(new_entry)
        history = history[-288:]

        # Calculate average
        avg_rpm = round(sum(entry["rpm"] for entry in history) / len(history), 2)

        # Update DB for this pet
        cursor.execute("""
            UPDATE pet_vitals
            SET 
                current_rpm = %s,
                avg_rpm = %s,
                vitals_history = %s
            WHERE pet_id = %s
        """, (
            new_rpm,
            avg_rpm,
            json.dumps(history),
            pet_id
        ))

        print(f"[✓] Updated pet {pet_id} → RPM: {new_rpm} | AVG RPM: {avg_rpm:.2f}")

    conn.commit()
    cursor.close()
    conn.close()

# Loop every 5 minutes (300s)
while True:
    update_all_pets()
    time.sleep(300)